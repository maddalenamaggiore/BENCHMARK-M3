CREATE DATABASE ToysGroup;

USE ToysGroup;

CREATE TABLE Product
(ID_Product VARCHAR (25) PRIMARY KEY,
Name_Product VARCHAR (250),
Category VARCHAR (25),
Product_Price NUMERIC (10,2));

CREATE TABLE Region
(ID_Region INTEGER PRIMARY KEY,
Region VARCHAR (25),
Territory VARCHAR (25));

CREATE TABLE Sales
(ID_Sales VARCHAR (25) PRIMARY KEY,
Name_Sales VARCHAR (250),
ID_Product VARCHAR (25),
Sales_Date DATE,
Sales_Ammount NUMERIC (10,2),
ID_Region INTEGER,
FOREIGN KEY (ID_Product) REFERENCES Product (ID_Product),
FOREIGN KEY (ID_Region) REFERENCES Region (ID_Region));

INSERT INTO Product
VALUES ('B-225', 'Bike Firebolt','B1KE', '2000.00'),
('B-227', 'Bike Nimbus2000', 'B1KE', '1999.00'),
('S-770', 'Skateboard SilverSurf', '5K@TE', '5.00'),
('R-002', 'Rollers Barbie', 'R0LL3R', '250.00'),
('R-004', 'Rollers Ombromanto',	'R0LL3R', '420.69'),
('N-025', 'Slitta di Babbo Natale',	'N@TAL3', '25.12');

INSERT INTO Region
VALUES ('1', 'Italia', 'Mondo'),
('2', 'Narnia', 'Fantasy'),
('3', 'Wakanda', 'Fantasy'),
('4', 'North Korea', 'Mondo'),
('5', 'La Morte Nera', 'Fantasy'),
('6', 'Lapponia', 'Mondo');

INSERT INTO Sales
VALUES ('B01', 'Pinco Pallo', 'B-225', '29/02/2020', '2000.00', '3'),
('A08', 'Antonio Rossi', 'N-025', '24/12/2023', '25.12', '5'),
('M29', 'Maddalena Maggiore', 'R-004', '01/01/2024', '420.69', '1'),
('A27', 'Ermenegildo Paoli', 'B-225', '01/04/2000',	'2000.00', '2'),
('D04',	'Bruno Orso', 'B-227', '24/12/2023', '1999.00', '5');

SELECT
*
FROM Product;

SELECT
*
FROM Region;

SELECT
*
FROM Sales;

SELECT
ID_Product, COUNT(ID_Product) AS Duplicati
FROM Product
GROUP BY ID_Product
HAVING COUNT(ID_Product) > 1;

SELECT
ID_Region, COUNT(ID_Region) AS Duplicati
FROM Region
GROUP BY ID_Region
HAVING COUNT(ID_Region) > 1;

SELECT
ID_Sales, COUNT(ID_Sales) AS Duplicati
FROM Sales
GROUP BY ID_Sales
HAVING COUNT(ID_Sales) > 1;

SELECT
S.ID_Product, S.Sales_Date, P.Name_Product, P.Category, R.Territory, R.Region,
CASE WHEN
DATEDIFF (DAY, S.Sales_Date, CURRENT_TIMESTAMP) > 180
THEN 'True' ELSE 'False'END
AS Campo_Booleano
FROM Sales AS S
LEFT JOIN Product AS P
ON S.ID_Product = P.ID_Product
LEFT JOIN Region AS R
ON S.ID_Region = R.ID_Region;

SELECT
P.Name_Product,
YEAR (S.Sales_Date) AS Sales_Year, SUM (S.Sales_Ammount) AS Total
FROM Product AS P
INNER JOIN Sales AS S
ON P.ID_Product = S.ID_Product
GROUP BY P.Name_Product, YEAR (S.Sales_Date);

SELECT
R.Territory, YEAR (S.Sales_Date) AS Sales_Year, SUM (S.Sales_Ammount) AS Total
FROM Region AS R
INNER JOIN Sales AS S
ON R.ID_Region = S.ID_Region
GROUP BY R.Territory, YEAR (S.Sales_Date)
ORDER BY Sales_Year, Total DESC;

SELECT TOP 1
P.Name_Product, COUNT (S.ID_Product) AS Qnt
FROM Product AS P
INNER JOIN Sales AS S
ON P.ID_Product = S.ID_Product
GROUP BY P.Name_Product;

SELECT
P.Name_Product, S.Sales_Ammount
FROM Product AS P
LEFT JOIN Sales AS S
ON P.ID_Product = S.ID_Product
WHERE S.Sales_Ammount IS NULL;

SELECT P.Name_Product
FROM Product AS P
WHERE P.ID_Product NOT IN (SELECT DISTINCT S.ID_Product FROM Sales AS S);

SELECT
P.Name_Product, MAX(S.Sales_Date) AS Ultima
FROM Product AS P
LEFT JOIN Sales AS S
ON P.ID_Product = S.ID_Product
GROUP BY P.Name_Product
ORDER BY Ultima DESC;

CREATE VIEW Product_View AS
SELECT
ID_Product, Name_Product, Category 
FROM Product;

CREATE VIEW Region_View AS
SELECT
*
FROM Region;

CREATE VIEW Sales_View AS
SELECT
P.ID_Product, P.Name_Product, P.Category, P.Product_Price, S.ID_Sales, S.Name_Sales, S.Sales_Date, S.Sales_Ammount, R.ID_Region, R.Region, R.Territory
FROM Product AS P
FULL OUTER JOIN Sales AS S
ON P.ID_Product = S.ID_Product
FULL OUTER JOIN Region AS R
ON S.ID_Region = R.ID_Region;
